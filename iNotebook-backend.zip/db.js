// Purpose- Establishing connection to mongodb


// Importing mongoose module
const mongoose = require("mongoose"); 
// on some system mongodb://localhost:27017/ connection string will not work instead use mongodb://0.0.0.0:27017/

// Assigning connection string to a variable
const mongoURI = process.env.MONGO_URL;


const connectToMongo = () => {
    mongoose.connect(mongoURI)
    console.log("Connected to mongo successfully");
 
}


module.exports = connectToMongo;  


