const express = require("express");

// importing the User.js module to define schema
const User = require("../models/User");
const router = express.Router();
// importing validator module
const { body, query, validationResult } = require("express-validator");

//importing bcryptjs to enhance password security
const bcrypt = require("bcryptjs");

// Importing module for implementing JWT authentication
jwt = require("jsonwebtoken");

// Importing fetchuser module
var fetchuser = require("../middleware/fetchuser");

// JWT Authentication
const JWT_SECRET = "Ganeshisagood$boy";

//ROUTE 1: create user using: POST '/api/auth/createuser' API endpoint . No login required.
router.post(
  "/createuser",
  [
    body("name", "Enter a valid name").isLength({ min: 3 }), //Added validation layer
    body("email", "Enter a valid email").isEmail(),
    body("password", "Password must be at least 5 charecters").isLength({
      min: 3,
    }),
  ],
  async (req, res) => {
    let success = false;
    const result = validationResult(req);
    // console.log("Result ${result} ");

    //  if there are validation errors Return the bad requests and return the error message.
    if (!result.isEmpty()) {
      return res.send({ errors: result.array() });
    }

    try {
      // Check whether the user with this email exists already, helping to insert unique email in mongodb
      let user = await User.findOne({ email: req.body.email });

      if (user) {
        return res
          .status(400)
          .json({ success, error: "Sorry a user with this email already exists" });
      }

      const salt = await bcrypt.genSalt(10); //generating salt
      const secPass = await bcrypt.hash(req.body.password, salt); //generating hash
      // creating user details in mongodb,
      user = await User.create({
        name: req.body.name,
        password: secPass,
        email: req.body.email,
      });

      const data = {
        user: {
          id: user.id,
        },
      };
      // signing the jwt token
      const authToken = jwt.sign(data, JWT_SECRET);
      // console.log(jwtData)
      success = true;
      res.json({success, authToken });
    } catch (error) {
      console.error(error.message);
      res.status(500).send("Internal Server Error");
    }
  }
);

//ROUTE 2: Authenticate a user using: POST '/api/auth/login' API endpoint . No login required.
router.post(
  "/login",
  [
    body("email", "Enter a valid email").isEmail(),
    body("password", "Password cannot be blank").exists(),
  ],
  async (req, res) => {
    let success = false;
    const result = validationResult(req);
    // console.log("Result ${result} ");

    //  if there are validation errors Return the bad requests and return the error message.
    if (!result.isEmpty()) {
      return res.send({ errors: result.array() });
    }

    const { email, password } = req.body;
    try {
      let user = await User.findOne({ email });// Checking whether email provided in request body is available in Mongodb or not
      if (!user) {
        return res
          .status(400)
          .json({ error: "Please try to login with correct credentials" });
      }
      const passwordCompare = await bcrypt.compare(password, user.password);//Checking whether password is correct or not

      if (!passwordCompare) {
        success = false
        return res
          .status(400)
          .json({ success, error: "Please try to login with correct credentials" });
      }

      const data = {
        user: {
          id: user.id,
        },
      };
      // console.log(data);

      const authtoken = jwt.sign(data, JWT_SECRET);
      success = true
      res.json({ success, authtoken });
    } catch (error) {
      console.error(error.message);
      res.status(500).send("Internal Server Error");
    }
  }
);

// ROUTE 3: Get loggedin User Details using: POST "/api/auth/getuser". Login required
router.post("/getuser", fetchuser, async (req, res) => { //added fetchuser middleware
  try {
    userId = req.user.id;
    const user = await User.findById(userId) .select("-password");//finding user details in MongoDB using userId except password
    res.send(user);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Internal Server Error");
  }
});

module.exports = router;
