// importing the db.js module
require('dotenv').config()
const connectToMongo = require("./db");

// importing the express module
const express = require('express');
var cors = require('cors')
const app = express()
const port = process.env.PORT

console.log(process.env.MONGO_URL);
console.log(process.env.PORT);

connectToMongo(); 

app.use(cors())
 
// Middleware to use request body
app.use(express.json()); 
 
// Available routes
// created /api/auth api endpoint
app.use('/api/auth', require('./routes/auth')); 
 
// created /api/notes api endpoint 
app.use('/api/notes', require('./routes/notes'));     

     
 

app.listen(port, () => {
  console.log(`iNotebook app listening at http://localhost:${port}`)
})  
  
  
     