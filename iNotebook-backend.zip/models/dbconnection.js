// Purpose - Learnt the mongodb connection

const mongoose = require('mongoose');

mongoose.connect('mongodb://0.0.0.0:27017/ganesh')

.then( ()=>{
    console.log("Connected successfully");
})

.catch (()=>{
    console.log('error');
})
 
const testSchema = new mongoose.Schema({
    name:{
        type:String,
        require : true
    }
})

const collection = new mongoose.model('one', testSchema)

data = {
    name:'check'
} 

collection.insertMany([data])
console.log('done')     

