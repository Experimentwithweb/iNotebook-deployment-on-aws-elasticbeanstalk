// Purpose -Show the content for about page.

import React from 'react';  //Use rafce shortcut to create component

const About = () => {



  return (  //render method of about component
    <div>
      This is About 
    </div>
  )
}

export default About;
